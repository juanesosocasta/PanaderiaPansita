package panaderia.vista;

public class Principal {

	public static void main(String[] args) {
		ProgramaPancita programa = new ProgramaPancita();
		programa.iniciar();
		programa.hacerRecorrido();
	}
}
